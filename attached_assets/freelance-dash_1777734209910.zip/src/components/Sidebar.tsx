import { motion } from "motion/react";
import { Link } from "react-router-dom";
import {
  BriefcaseIcon,
  CreditCardIcon,
  Squares2X2Icon,
  ChatBubbleBottomCenterTextIcon,
  Cog6ToothIcon,
  UsersIcon,
} from "@heroicons/react/24/outline";

const NAV_ITEMS = [
  { name: "Overview", icon: Squares2X2Icon, active: true },
  { name: "Projects", icon: BriefcaseIcon },
  { name: "Clients", icon: UsersIcon },
  { name: "Messages", icon: ChatBubbleBottomCenterTextIcon },
  { name: "Invoices", icon: CreditCardIcon },
  { name: "Settings", icon: Cog6ToothIcon },
];

export function Sidebar() {
  return (
    <aside className="w-64 h-screen hidden md:flex flex-col fixed left-0 top-0 bg-[#fbfbfd] border-r border-black/10 z-20">
      <div className="p-8 pb-4">
        <Link to="/" className="flex items-center gap-2 hover:opacity-60 transition-opacity">
          <span className="font-semibold text-xl tracking-tight">Freelance.</span>
        </Link>
      </div>

      <nav className="flex-1 px-6 space-y-1 mt-6">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = item.active;

          return (
            <button
              key={item.name}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-md transition-all duration-200 group relative ${
                isActive
                  ? "text-black"
                  : "text-[#86868b] hover:text-black"
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="active-nav"
                  className="absolute inset-0 bg-black/5 rounded-md -z-10"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              <Icon className={`w-5 h-5 ${isActive ? "text-black" : ""}`} strokeWidth={isActive ? 2.5 : 2} />
              <span className="font-medium text-[14px]">{item.name}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-6 mt-auto border-t border-black/10 mx-6 mb-6">
        <div className="flex items-center gap-3 cursor-pointer group">
          <img
            src="https://api.dicebear.com/7.x/notionists/svg?seed=Felix&backgroundColor=f5f5f7"
            alt="User avatar"
            className="w-9 h-9 rounded-full border border-black/10"
          />
          <div className="flex flex-col text-left">
            <span className="text-[14px] font-medium text-black">Jon D.</span>
            <span className="text-[12px] text-[#86868b]">Pro Plan</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
