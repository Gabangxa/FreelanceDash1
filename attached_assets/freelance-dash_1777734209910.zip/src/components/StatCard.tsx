import React from "react";
import { motion } from "motion/react";

interface StatCardProps {
  key?: string;
  title: string;
  value: string;
  trend: string;
  isPositive: boolean;
  icon: React.ElementType;
  delay?: number;
  hideBorder?: boolean;
}

export function StatCard({ title, value, trend, isPositive, icon: Icon, delay = 0, hideBorder }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay, ease: [0.23, 1, 0.32, 1] }}
      className={`flex flex-col py-2 ${!hideBorder ? "lg:border-r border-black/10 lg:pr-8" : ""}`}
    >
      <div className="flex items-center gap-2 mb-3 text-[#86868b]">
        <Icon className="w-4 h-4" strokeWidth={2} />
        <span className="text-xs font-semibold tracking-widest uppercase">{title}</span>
      </div>
      <div className="flex items-baseline gap-3">
        <span className="text-4xl md:text-5xl font-light tracking-tight">{value}</span>
        <div
          className={`text-sm font-medium ${
            isPositive ? "text-[#34C759]" : "text-[#FF3B30]"
          }`}
        >
          {isPositive ? "+" : "-"}{trend}
        </div>
      </div>
    </motion.div>
  );
}
