import { motion } from "motion/react";
import { ChevronRightIcon } from "@heroicons/react/24/outline";

const PROJECTS = [
  {
    id: 1,
    name: "Fintech Mobile App",
    client: "Stripe Inc.",
    status: "In Progress",
    progress: 75,
    dueDate: "2 days left",
  },
  {
    id: 2,
    name: "E-commerce Redesign",
    client: "Nike",
    status: "Review",
    progress: 90,
    dueDate: "Tomorrow",
  },
  {
    id: 3,
    name: "Marketing Website",
    client: "Acme Corp",
    status: "Planning",
    progress: 20,
    dueDate: "Next week",
  },
];

export function RecentProjects() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3, ease: [0.23, 1, 0.32, 1] }}
      className="md:col-span-2 flex flex-col"
    >
      <div className="flex items-center justify-between border-b border-black/10 pb-4 mb-4">
        <h2 className="text-xl font-medium tracking-tight">Active Projects</h2>
        <button className="text-sm font-medium text-[#0071e3] hover:text-[#0077ed] transition-colors">
          View all
        </button>
      </div>

      <div className="flex flex-col">
        {PROJECTS.map((project, idx) => (
          <div
            key={project.id}
            className="flex items-center justify-between py-4 border-b border-black/5 hover:bg-black/[0.02] transition-colors group cursor-pointer px-2 -mx-2 rounded-lg"
          >
            <div className="flex items-center gap-4">
              <div>
                <h4 className="font-medium text-[16px] tracking-tight">{project.name}</h4>
                <p className="text-sm text-[#86868b] mt-0.5">{project.client}</p>
              </div>
            </div>

            <div className="hidden md:flex flex-col items-end gap-2 w-32">
              <div className="w-full flex justify-between text-[11px] font-semibold tracking-wider uppercase">
                <span className="text-[#86868b]">{project.status}</span>
                <span>{project.progress}%</span>
              </div>
              <div className="w-full h-1 bg-black/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-black rounded-full transition-all duration-1000 ease-out"
                  style={{ width: `${project.progress}%` }}
                />
              </div>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-[13px] font-medium text-[#86868b] hidden sm:block w-24 text-right">
                {project.dueDate}
              </span>
              <ChevronRightIcon className="w-4 h-4 text-[#86868b] opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
