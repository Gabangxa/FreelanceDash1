import { BellIcon, Bars3Icon, MagnifyingGlassIcon } from "@heroicons/react/24/outline";

export function Header() {
  return (
    <header className="h-24 px-6 md:px-12 flex items-center justify-between sticky top-0 z-10 bg-[#fbfbfd]/90 backdrop-blur-xl">
      <div className="flex items-center gap-4">
        <button className="md:hidden p-2 -ml-2 text-black hover:bg-black/5 rounded-full transition-colors">
          <Bars3Icon className="w-6 h-6" strokeWidth={1.5} />
        </button>
        {/* We moved the page title directly into the Dashboard body for a cleaner document look */}
      </div>

      <div className="flex items-center gap-6 ml-auto">
        <div className="relative hidden md:block">
          <MagnifyingGlassIcon
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[#86868b] w-4 h-4"
          />
          <input
            type="text"
            placeholder="Search"
            className="w-64 pl-9 pr-4 py-1.5 rounded-full bg-black/5 border-none outline-none text-[15px] focus:bg-white focus:ring-1 focus:ring-black/20 transition-all placeholder:text-[#86868b]"
          />
        </div>

        <button className="relative p-2 rounded-full hover:bg-black/5 transition-colors">
          <BellIcon className="w-5 h-5 text-[#1d1d1f]" strokeWidth={2} />
          <span className="absolute top-2 right-2 w-2 h-2 bg-[#FF3B30] rounded-full ring-2 ring-[#fbfbfd]"></span>
        </button>
      </div>
    </header>
  );
}
