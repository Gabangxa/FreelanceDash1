import { Header } from "./Header";
import { Sidebar } from "./Sidebar";
import { StatCard } from "./StatCard";
import { RecentProjects } from "./RecentProjects";
import { EarningsChart } from "./EarningsChart";
import { CheckCircleIcon, ClockIcon, CurrencyDollarIcon, RocketLaunchIcon } from "@heroicons/react/24/outline";
import { motion } from "motion/react";

const STATS = [
  {
    title: "Balance",
    value: "$24,500",
    trend: "2.5%",
    isPositive: true,
    icon: CurrencyDollarIcon,
  },
  {
    title: "Projects",
    value: "12",
    trend: "1",
    isPositive: true,
    icon: RocketLaunchIcon,
  },
  {
    title: "Completed",
    value: "48",
    trend: "12%",
    isPositive: true,
    icon: CheckCircleIcon,
  },
  {
    title: "Hours",
    value: "164",
    trend: "5.2%",
    isPositive: false,
    icon: ClockIcon,
  },
];

export function Dashboard() {
  return (
    <div className="flex min-h-screen bg-[#fbfbfd]">
      <Sidebar />
      <main className="flex-1 md:ml-64 flex flex-col relative w-full overflow-hidden">
        <Header />
        
        <div className="px-6 md:px-12 py-8 max-w-6xl mx-auto w-full space-y-12 pb-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
            className="border-b border-black/10 pb-8"
          >
            <h2 className="text-4xl md:text-5xl font-light tracking-tight text-black">Good morning, Jon.</h2>
          </motion.div>

          {/* Stats Row - Flat and Borderless */}
          <div className="grid grid-cols-2 lg:flex lg:flex-row gap-8 lg:gap-12 w-full">
            {STATS.map((stat, i) => (
              <div key={stat.title} className="flex-1">
                <StatCard
                  title={stat.title}
                  value={stat.value}
                  trend={stat.trend}
                  isPositive={stat.isPositive}
                  icon={stat.icon}
                  delay={i * 0.1}
                  hideBorder={i === STATS.length - 1} // Hide border on the last item
                />
              </div>
            ))}
          </div>

          {/* Charts and Projects without cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 lg:gap-16 pt-8">
            <RecentProjects />
            <EarningsChart />
          </div>
        </div>
      </main>
    </div>
  );
}
