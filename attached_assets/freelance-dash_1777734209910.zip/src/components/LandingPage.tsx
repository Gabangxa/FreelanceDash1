import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { ArrowRightIcon, Squares2X2Icon, ShieldCheckIcon } from "@heroicons/react/24/outline";

export function LandingPage() {
  return (
    <div className="min-h-screen bg-[#fbfbfd] text-[#1d1d1f] selection:bg-black/10 font-sans">
      {/* Navigation Minimal */}
      <nav className="fixed top-0 left-0 right-0 py-6 px-8 z-50 bg-[#fbfbfd]/80 backdrop-blur-xl border-b border-black/5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-xl tracking-tight">Freelance.</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-[15px] font-medium">
          <a href="#features" className="text-[#1d1d1f] hover:opacity-60 transition-opacity">Features</a>
          <a href="#testimonials" className="text-[#1d1d1f] hover:opacity-60 transition-opacity">Stories</a>
          <a href="#pricing" className="text-[#1d1d1f] hover:opacity-60 transition-opacity">Pricing</a>
        </div>
        <div>
          <Link
            to="/dashboard"
            className="text-[#1d1d1f] font-medium text-[15px] hover:opacity-60 transition-opacity flex items-center gap-1"
          >
            Open App <ArrowRightIcon className="w-4 h-4" />
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-48 pb-32 px-6 md:px-12 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}
          className="max-w-4xl mx-auto"
        >
          <h1 className="text-6xl md:text-[88px] font-medium tracking-tighter text-balance leading-[1.05] mb-8">
            Focus on the work.<br/>
            <span className="text-[#86868b]">We'll handle the rest.</span>
          </h1>

          <p className="text-xl md:text-2xl text-[#86868b] max-w-2xl mx-auto mb-16 font-normal tracking-tight leading-snug">
            A frictionless environment for independent professionals to track projects, monitor earnings, and stay flawlessly organized.
          </p>

          <div className="flex items-center justify-center">
            <Link
              to="/dashboard"
              className="bg-[#1d1d1f] text-white px-8 py-4 rounded-full text-lg font-medium hover:bg-black transition-colors shadow-lg flex items-center gap-2 group"
            >
              Start building
            </Link>
          </div>
        </motion.div>

        {/* Hero Minimal Mockup */}
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3, ease: [0.23, 1, 0.32, 1] }}
          className="mt-32 w-full max-w-5xl"
        >
          <div className="w-full bg-white rounded-t-[32px] border border-b-0 border-black/10 shadow-2xl p-4 md:p-8 flex flex-col relative overflow-hidden h-[400px]">
            <div className="flex gap-2 items-center mb-10 px-2">
               <div className="w-3 h-3 rounded-full bg-red-400" />
               <div className="w-3 h-3 rounded-full bg-amber-400" />
               <div className="w-3 h-3 rounded-full bg-green-400" />
            </div>
            {/* Minimal UI Wireframe */}
            <div className="flex gap-12 px-2">
               {/* Sidebar */}
               <div className="w-48 hidden md:flex flex-col gap-6">
                  <div className="w-full h-3 bg-black/5 rounded-full" />
                  <div className="w-3/4 h-3 bg-black/5 rounded-full" />
                  <div className="w-5/6 h-3 bg-black/5 rounded-full" />
               </div>
               {/* Main Content */}
               <div className="flex-1 flex flex-col gap-10">
                  <div className="w-1/3 h-10 bg-black/10 rounded-sm mb-4" />
                  <div className="grid grid-cols-3 gap-8">
                    <div className="h-16 border-t border-black/10 pt-4"><div className="w-1/2 h-8 bg-black/5 rounded-sm" /></div>
                    <div className="h-16 border-t border-black/10 pt-4"><div className="w-2/3 h-8 bg-black/5 rounded-sm" /></div>
                    <div className="h-16 border-t border-black/10 pt-4"><div className="w-1/2 h-8 bg-black/5 rounded-sm" /></div>
                  </div>
                  <div className="h-48 border-t border-black/10 bg-gradient-to-t from-black/5 to-transparent w-full mt-4" />
               </div>
            </div>
            {/* Gradient fade overlay to melt into background */}
            <div className="absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-white via-white/80 to-transparent" />
          </div>
        </motion.div>
      </section>

      {/* Minimalist Features Section */}
      <section id="features" className="py-32 px-6 md:px-12 bg-white border-t border-black/5 pt-40">
        <div className="max-w-5xl mx-auto">
          <div className="mb-24">
            <h2 className="text-4xl md:text-5xl font-medium tracking-tight">Exceptional by design.</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-x-16 gap-y-16">
             <div className="flex flex-col border-t border-black/10 pt-6">
                <Squares2X2Icon className="mb-6 font-light w-8 h-8" strokeWidth={1.5} />
                <h3 className="text-[22px] font-medium mb-3 tracking-tight">Intuitive view</h3>
                <p className="text-[#86868b] text-[16px] leading-relaxed">
                  See all your vital signs at a glance without navigating through endless menus. A true canvas for your career.
                </p>
             </div>
             <div className="flex flex-col border-t border-black/10 pt-6">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="mb-6 w-8 h-8">
                  <path fillRule="evenodd" d="M21.53 9.53a.75.75 0 0 1-1.06 0l-4.72-4.72V15a6.75 6.75 0 0 1-13.5 0v-3a.75.75 0 0 1 1.5 0v3a5.25 5.25 0 1 0 10.5 0V4.81L9.53 9.53a.75.75 0 0 1-1.06-1.06l6-6a.75.75 0 0 1 1.06 0l6 6a.75.75 0 0 1 0 1.06Z" clipRule="evenodd" />
                </svg>
                <h3 className="text-[22px] font-medium mb-3 tracking-tight">Zero friction</h3>
                <p className="text-[#86868b] text-[16px] leading-relaxed">
                  Engineered for unparalleled responsiveness. Every single interaction feels instantaneous and natural.
                </p>
             </div>
             <div className="flex flex-col border-t border-black/10 pt-6">
                <ShieldCheckIcon className="mb-6 font-light w-8 h-8" strokeWidth={1.5} />
                <h3 className="text-[22px] font-medium mb-3 tracking-tight">Absolute privacy</h3>
                <p className="text-[#86868b] text-[16px] leading-relaxed">
                  Your client data and financials remain strictly yours. Advanced architecture ensures complete peace of mind.
                </p>
             </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 md:px-12 bg-white flex flex-col md:flex-row items-center justify-between border-t border-black/5">
         <span className="font-semibold text-lg tracking-tight mb-4 md:mb-0">Freelance.</span>
         <p className="text-[#86868b] text-sm">© 2024 Freelance Pro. Designed with intent.</p>
      </footer>
    </div>
  );
}
