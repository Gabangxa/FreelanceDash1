import { motion } from "motion/react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";

const DATA = [
  { name: "Mon", total: 1200 },
  { name: "Tue", total: 900 },
  { name: "Wed", total: 1600 },
  { name: "Thu", total: 1400 },
  { name: "Fri", total: 2100 },
  { name: "Sat", total: 1800 },
  { name: "Sun", total: 2400 },
];

export function EarningsChart() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.4, ease: [0.23, 1, 0.32, 1] }}
      className="flex flex-col md:col-span-1"
    >
      <div className="flex items-end justify-between border-b border-black/10 pb-4 mb-8">
        <h2 className="text-xl font-medium tracking-tight">Earnings</h2>
        <h3 className="text-2xl font-light tracking-tight">$11,400</h3>
      </div>

      <div className="flex-1 min-h-[220px] w-full mt-2">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={DATA} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#1d1d1f" stopOpacity={0.05} />
                <stop offset="95%" stopColor="#1d1d1f" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="name"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 11, fill: "#86868b" }}
              dy={10}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(255, 255, 255, 0.9)",
                backdropFilter: "blur(12px)",
                border: "none",
                borderRadius: "12px",
                boxShadow: "0 4px 20px rgba(0,0,0,0.08)",
              }}
              itemStyle={{ color: "#1d1d1f", fontWeight: 500 }}
              cursor={{ stroke: "rgba(0,0,0,0.1)", strokeWidth: 1, strokeDasharray: "4 4" }}
            />
            <Area
              type="monotone"
              dataKey="total"
              stroke="#1d1d1f"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorTotal)"
              animationDuration={1500}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}
